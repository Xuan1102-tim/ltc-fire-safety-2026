/* QUESTION_CONFIG */
// Room state belongs to this controller session, never restored from a prior lecture.
let dmRoom = null, dmPaused = false, dmAPI = null, dmStop = null, dmRoomStop = null;
let dmSeen = new Set(), dmQueue = [], dmLanes = new Set(), dmSequence = 0;
const dmLayer = document.createElement('div'); dmLayer.className = 'dm-layer'; dmLayer.setAttribute('aria-hidden','true'); document.body.append(dmLayer);
const dmQR = document.createElement('button'); dmQR.className='dm-qr'; dmQR.hidden=true; dmQR.setAttribute('aria-label','放大掃碼提問 QR Code'); document.body.append(dmQR);
const dmPanel = document.createElement('aside'); dmPanel.className='dm-panel'; dmPanel.hidden=true; dmPanel.setAttribute('aria-label','課堂提問控制');
dmPanel.innerHTML='<button class="dm-close">關閉</button><h2>課堂提問</h2><output role="status">開啟本場提問後，學員掃碼即可送出問題。</output><div class="dm-actions"><button class="dm-start">開啟本場提問</button><button class="dm-pause" disabled>暫停彈幕</button><button class="dm-clear" disabled>清除畫面</button><button class="dm-end" disabled>結束本場提問</button></div><div class="dm-large"></div><a class="dm-link" target="_blank" rel="noopener"></a><p>每則最多 80 字，10 秒可送一次。暫停彈幕仍會收件，問題保留在下方。</p><h3>收到的問題 <span class="dm-count">0</span></h3><ol class="dm-list"></ol>';
document.body.append(dmPanel);
dmPanel.addEventListener('click',e=>e.stopPropagation()); dmPanel.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape')dmPanel.hidden=true});
dmPanel.querySelector('.dm-close').onclick=()=>dmPanel.hidden=true;
const dmStatus=message=>dmPanel.querySelector('output').textContent=message;
const dmToggle=document.createElement('button'); dmToggle.textContent='課堂提問'; dmToggle.onclick=()=>dmPanel.hidden=!dmPanel.hidden;
if(!isProjector){document.getElementById('presenterBtn').after(dmToggle);const p=dmToggle.cloneNode(true);p.onclick=dmToggle.onclick;document.getElementById('pReveal').after(p)}
dmQR.onclick=()=>{dmPanel.hidden=false};
function dmSnapshot(){return {room:dmRoom,paused:dmPaused};}
function dmApply(state){
  const changed=dmRoom?.id!==state.room?.id; dmRoom=state.room;dmPaused=!!state.paused;
  if(changed){dmSeen.clear();dmClear()}
  document.body.classList.toggle('dm-active',!!dmRoom);dmQR.hidden=!dmRoom;
  if(dmRoom){const qr=qrcode(0,'M');qr.addData(dmRoom.url);qr.make();const svg=qr.createSvgTag({cellSize:4,margin:16,scalable:true});dmQR.innerHTML=svg+'<span>掃碼提問 · 點此放大</span>';dmPanel.querySelector('.dm-large').innerHTML=svg;const a=dmPanel.querySelector('.dm-link');a.href=dmRoom.url;a.textContent='開啟學員提問頁';}
  else {dmPanel.querySelector('.dm-large').replaceChildren();dmPanel.querySelector('.dm-link').removeAttribute('href');dmPanel.querySelector('.dm-link').textContent='';}
  dmPanel.querySelector('.dm-start').disabled=isProjector||!!dmRoom;
  for(const name of ['pause','clear','end'])dmPanel.querySelector('.dm-'+name).disabled=isProjector||!dmRoom;
  dmPanel.querySelector('.dm-pause').textContent=dmPaused?'恢復彈幕':'暫停彈幕';
}
function dmClear(){dmQueue=[];dmSequence++;dmLayer.replaceChildren();dmLanes.clear()}
function dmPump(){
  if(dmPaused||!dmRoom)return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  while(dmQueue.length&&dmLanes.size<(reduced?1:2)){
    const lane=dmLanes.has(0)?1:0,m=dmQueue.shift(),el=document.createElement('div'),generation=dmSequence;
    dmLanes.add(lane);el.className='dm-message'+(reduced?' dm-still':'');el.style.top=(lane*72)+'px';
    const tag=document.createElement('mark');tag.textContent='學員提問';el.append(tag,document.createTextNode(m.text));dmLayer.append(el);
    el.style.setProperty('--dm-travel',-(dmLayer.clientWidth+el.offsetWidth+30)+'px');
    setTimeout(()=>{el.remove();if(generation!==dmSequence)return;dmLanes.delete(lane);dmPump()},reduced?8000:10100);
  }
}
function dmReceive(message){if(dmSeen.has(message.id))return;dmSeen.add(message.id);if(!dmPaused){if(dmQueue.length===20)dmQueue.shift();dmQueue.push(message);dmPump()}}
function dmRelay(type,data={}){send({type:'danmaku',action:type,...data})}
if(channel)channel.addEventListener('message',e=>{
  const m=e.data;if(!m)return;
  if(!isProjector&&m.type==='state-request'&&(!m.session||m.session===sessionId)){dmRelay('state',{state:dmSnapshot()});return}
  if(!isProjector||m.type!=='danmaku'||!controllerId||m.session!==controllerId)return;
  if(m.action==='state')dmApply(m.state);if(m.action==='message')dmReceive(m.message);if(m.action==='clear')dmClear();
});
let dmPageTimer;
new MutationObserver(()=>{if(isProjector||!dmRoom||!dmAPI)return;clearTimeout(dmPageTimer);dmPageTimer=setTimeout(()=>{if(dmRoom)dmAPI.updateDoc(dmAPI.doc(dmAPI.db,QUESTION_CONFIG.collection,dmRoom.id),{scene:String(slides[i].dataset.scene)}).catch(()=>dmStatus('頁碼同步暫時中斷；請確認網路。'))},600)}).observe(document.querySelector('.deck'),{subtree:true,attributes:true,attributeFilter:['class']});
dmPanel.querySelector('.dm-start').onclick=async()=>{
  const button=dmPanel.querySelector('.dm-start');button.disabled=true;dmStatus('正在連線並建立本場提問…');
  try{
    if(!navigator.onLine)throw Error('offline');dmAPI ||= await connectQuestions(QUESTION_CONFIG);const f=dmAPI, ref=f.doc(f.collection(f.db,QUESTION_CONFIG.collection));
    const expiry=Date.now()+(5*60+55)*60*1000;
    await f.setDoc(ref,{owner:f.user.uid,open:true,createdAt:f.serverTimestamp(),expiresAt:f.Timestamp.fromMillis(expiry),scene:String(slides[i].dataset.scene)});
    dmPanel.querySelector('.dm-list').replaceChildren();dmPanel.querySelector('.dm-count').textContent='0';
    dmApply({room:{id:ref.id,url:QUESTION_CONFIG.publicQuestionUrl+'#'+ref.id,expiresAt:expiry},paused:false});dmRelay('state',{state:dmSnapshot()});dmStatus('本場提問已開啟，請學員掃描右下角 QR Code。');
    dmStop=f.onSnapshot(f.query(f.collection(ref,'messages'),f.orderBy('createdAt')),snapshot=>{
      for(const change of snapshot.docChanges()){if(change.type!=='added'||change.doc.metadata.hasPendingWrites||dmSeen.has(change.doc.id))continue;
        const m={id:change.doc.id,...change.doc.data()},li=document.createElement('li'),label=document.createElement('small');label.textContent=(m.scene==='cover'?'首頁':'第 '+m.scene+' 頁')+' · ';li.append(label,document.createTextNode(m.text));dmPanel.querySelector('.dm-list').prepend(li);dmPanel.querySelector('.dm-count').textContent=String(dmPanel.querySelector('.dm-list').children.length);dmReceive(m);dmRelay('message',{message:{id:m.id,text:m.text}});
      }
    },()=>dmStatus('收件連線中斷，請確認網路；既有問題仍保留。'));
    dmRoomStop=f.onSnapshot(ref,s=>{if(!s.exists()||!s.data().open){dmStop?.();dmApply({room:null,paused:false});dmRelay('state',{state:dmSnapshot()});dmStatus('本場提問已結束。')}});
  }catch(error){dmStatus('目前無法開啟提問，請確認網路後重試。簡報仍可照常授課。');button.disabled=false;console.error('Question room:',error.code||error.message)}
};
dmPanel.querySelector('.dm-pause').onclick=()=>{dmPaused=!dmPaused;dmClear();dmApply(dmSnapshot());dmRelay('state',{state:dmSnapshot()});dmRelay('clear');dmStatus(dmPaused?'彈幕已暫停，仍持續收件；可在下方閱讀問題。':'彈幕已恢復，只播放接下來的新問題。')};
dmPanel.querySelector('.dm-clear').onclick=()=>{dmClear();dmRelay('clear')};
dmPanel.querySelector('.dm-end').onclick=async()=>{try{await dmAPI.updateDoc(dmAPI.doc(dmAPI.db,QUESTION_CONFIG.collection,dmRoom.id),{open:false});dmStop?.();dmRoomStop?.();dmApply({room:null,paused:false});dmRelay('state',{state:dmSnapshot()});dmStatus('本場提問已結束，完整問題保留在此清單。')}catch{dmStatus('尚未成功結束，請連線後再試；不要先關閉主視窗。')}};
setInterval(()=>{if(dmRoom&&Date.now()>dmRoom.expiresAt){dmStop?.();dmRoomStop?.();dmApply({room:null,paused:false});if(!isProjector)dmRelay('state',{state:dmSnapshot()});dmStatus('本場提問已到期，請重新開啟新場次。')}},15000);
window.addEventListener('offline',()=>{if(dmRoom)dmStatus('目前離線，暫時無法接收問題。簡報仍可使用。')});
window.addEventListener('online',()=>{if(dmRoom)dmStatus('網路已恢復，正在重新連線。')});
window.addEventListener('beforeunload',e=>{if(!isProjector&&dmRoom){e.preventDefault();e.returnValue=''}});

