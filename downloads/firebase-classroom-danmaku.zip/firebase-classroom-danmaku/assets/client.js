// Loaded only after the lecturer starts a room, or a student opens the question page.
async function connectQuestions(options) {
  if(!options?.projectId||!options?.sdkVersion)throw Error('Missing confirmed Firebase configuration');
  const base = 'https://www.gstatic.com/firebasejs/'+options.sdkVersion+'/';
  // The official init.js endpoint supports script loading across origins;
  // init.json does not advertise CORS. Keep public app configuration out of Git.
  const configPromise = new Promise((resolve,reject)=>{
    const previous=window.firebase,script=document.createElement('script');let config;
    window.firebase={initializeApp:value=>{config=value}};
    const clean=()=>{script.remove();if(previous===undefined)delete window.firebase;else window.firebase=previous};
    script.onload=()=>{clean();config?resolve(config):reject(Error('設定未載入'))};
    script.onerror=()=>{clean();reject(Error('設定無法連線'))};
    script.src='https://'+options.projectId+'.firebaseapp.com/__/firebase/init.js';
    document.head.append(script);
  });
  const [appSDK, authSDK, dbSDK, config] = await Promise.all([
    import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'),
    import(base + 'firebase-firestore.js'), configPromise
  ]);
  if (config.projectId !== options.projectId) throw Error('課堂專案不符');
  const app = appSDK.initializeApp(config, 'classroom-questions-' + crypto.randomUUID());
  const auth = authSDK.initializeAuth(app, { persistence: authSDK.inMemoryPersistence });
  const { user } = await authSDK.signInAnonymously(auth);
  const db = dbSDK.getFirestore(app);
  return { ...dbSDK, db, user, dispose: async () => {
    await dbSDK.terminate(db); await authSDK.deleteUser(user); await appSDK.deleteApp(app);
  }};
}
