# 架構與整合

## 單一收件主視窗

主簡報建立房間、成為房主，維持唯一 Firestore 訊息 listener。投影和講師預覽透過既有 BroadcastChannel 接收主視窗事件，不各自登入或重複收件。這個通道只適合同一台電腦／同一瀏覽器來源；跨裝置投影要另外設計，不宣稱原範例已支援。

房間狀態包含 id、公開提問 url、expiresAt、paused；廣播另外攜帶控制會話 session。晚開投影先取得控制者，再取本場狀態，只播放後續新訊息。每則 ID 去重；換頁不重播、重新連線不重複顯示。清除、暫停與換場要讓所有視窗一致。

## 資料契約

| 路徑 | 資料／限制 |
| --- | --- |
| rooms/{roomId} | owner、open、createdAt、expiresAt、scene；roomId 為 Firestore 自動產生20碼 |
| rooms/{roomId}/messages/{id} | uid、text、scene、createdAt；只准新增，房主可讀與刪 |
| rooms/{roomId}/senders/{uid} | lastAt、messageId；與 message 在同一批次寫入 |

上表 rooms 是代稱，程式与規則使用設定中的 collection。createdAt 與 lastAt 用 serverTimestamp。伺服器規則以 getAfter 關聯兩筆原子写入，同時限制前一次送出間隔。學生不讀取其他人的問題；owner UID 可出現在房間資料，但權限必須以 request.auth.uid 判定，URL 上的 role 不能授權。

## 範例控制程式的適配契約

生成的 deck-integration.example.js 在既有控制 IIFE 裡執行，依賴：

- slides：所有投影片元素；i：當前索引；每頁 data-scene 為短識別字。
- isProjector、controllerId、sessionId：既有投影角色與主視窗會話。
- channel：BroadcastChannel 或 null；send(message)：自動帶 session 的廣播函式。
- connectQuestions(options)：生成的 client.js；qrcode：附帶 QR 程式庫。
- DOM：.deck、presenterBtn、pReveal；投影收件的既有 state-request／state 處理須先確立 controllerId。

不符合的專案應寫適配層或重構此範例，不應為湊 ID 改壞既有控制。留意主簡報的空白區點擊與快捷鍵：提問面板的事件不能觸發換頁。投影不建立房間或操作講師按鈕。學生頁的 publicQuestionUrl 必須是 HTTPS，QR 的 #roomId 不替換成 file 或 localhost。

預設 CSS 把 QR 放在右下角独立側欄；依投影尺寸重新驗證所有頁面的矩形、文字換行及捲動。不要只驗封面。動畫用純文字節點、固定兩條軌道、有限時間與有限佇列；結束或切換房間時清空舊動畫計時狀態。

## 生命週期

預設房間5小時55分到期、規則最多6小時，保留時鐘容差。明確結束成功後才提示可關閉主視窗。直接關閉主視窗後，舊房間可能收件至到期；過期不是自動刪除資料。若使用者需要課後留存、回復房主或自動清理，再針對該需求實作，不假設範例已具備。

匿名登入免填資料，不代表具名身分驗證。重新取得匿名身分會重置該身分的間隔，不把它稱為防濫用或防機器人。大量學員同網路的配額、測試與必要防護依实际規模決定。

## Firebase 連線

範例只有在講師按開啟／學員開頁時才載入 SDK；Firebase 失敗不阻止離線簡報。版本是產生器設定，不自動追最新版。client.js 可由官方 init.js 取得公開 Web App 設定，不含管理憑證。此方法先確認 endpoint 的 app 確實是目標 app；同一 project 多 app 時應改用明確的 Web App config。

Firebase 官方 init.json 在案例環境未提供跨來源 CORS；瀏覽器直接 fetch 會失敗。init.js 可用 script 載入，但此範例暫時使用 window.firebase 捕捉初始化設定，只適合原頁沒有並行 compat SDK 初始化的情況。已有 Firebase 的專案優先重用既有 app／驗證；不要覆寫正在工作的全域 SDK。
