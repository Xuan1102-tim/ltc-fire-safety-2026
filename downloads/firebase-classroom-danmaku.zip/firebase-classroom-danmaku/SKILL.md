---
name: firebase-classroom-danmaku
description: 為 HTML 教學簡報加入 Firebase 掃碼提問、即時彈幕、講師問題清單及投影同步。使用者要求學員掃 QR Code 打字並顯示在投影片、建立課堂彈幕，或套用 Firebase 課堂彈幕時使用；不涵蓋一般 Firebase 專案管理或投票文字雲。
---

# Firebase 課堂彈幕

把學員手機提問接到正在授課的 HTML 簡報，保留原來的換頁、講稿、素材與離線授課能力。這是功能整合技能，不是新建簡報或改寫教材的流程。

## 接續與授權

先讀當前專案規則、建置入口、投影通道與 Firebase 環境。分清正式專案、QA 副本、公開發布 checkout；不從 QA 副本提交或部署。已有專案／服務／目的地的授權可直接沿用，不因本技能重新詢問。

必須知道實際 project ID、使用服務和公開學員頁位置後才修改遠端。先讀取既有 Web App、Authentication、Firestore 規則；保留其他功能。若資訊缺少，先把本機可審查的整合做好，再一次詢問那個缺口。本技能本身不是部署、建立資源或擴大存取權的授權。

## 實作

1. 讀 [架構與整合](references/integration.md)，選擇與既有簡報相容的控制接口。
2. 讀 [規則、發布與驗證](references/verification.md)，保留房主授權、伺服器發送限制與證據邊界。
3. 用 scripts/materialize.mjs 產生可改寫的學員頁、連線程式、控制台範例與規則片段。它只產生本機檔案，不安裝、建立專案、部署或修改既有規則。
4. 在當前簡報的建置流程內嵌 CSS、QR 程式庫、Firebase 連線函式及適配後的控制程式。頁面載入時不主動連 Firebase；講師明確開啟本場才連線。
5. 執行實際雲端權限測試與瀏覽器送出→收件→投影流程；只在既有授權涵蓋發布時推送。最後交付操作步驟、可用網址、實測範圍與剩餘限制。

## 課堂體驗預設

開啟本場→連線成功→每頁角落顯示相同 QR→學員輸入→收到伺服器確認才顯示成功。下課結束本場，新開簡報不沿用舊頁碼或房間。

- 每則 80 字、每個匿名身分約 10 秒一次；須前後端一起調整。
- 最多兩條彈幕、約 10 秒離場、佇列上限 20；完整問題保留講師清單。
- 暫停只停止顯示，仍收件；恢復只顯示後續新問題。清除畫面不刪清單。
- 問題以 textContent／文字節點呈現，不執行 HTML。不要要求學生姓名或個案資料。
- QR 在本機生成，有白色留邊、可點擊放大；為它保留版面空間，不蓋住答案、影片或工具列。
- 減少動態偏好時改成短暫靜態卡。教材頁數、尺寸、位置與色彩依當前專案調整，不固定沿用案例數字。

這些是已用於線上授課的起點，可依使用者要求調整。調整字數、頻率、房間壽命時，同步改規則與測試；不要只改介面文案。

## 產生範例

建立一份 JSON 設定，包含 projectId、sdkVersion、collection、publicQuestionUrl 四個字串。projectId 與網址必須來自當前已確認的目的地；sdkVersion 查核 Firebase 官方文件後固定版本；collection 使用本功能獨立命名空間。

執行：node scripts/materialize.mjs /absolute/config.json /absolute/new-output-directory

輸出中的 deck-integration.example.js 依賴原簡報控制接口，先依 references/integration.md 適配，不能當成任意網站可直接載入的外掛。firestore.fragment.rules 只是需合併的片段，不是完整規則檔。
